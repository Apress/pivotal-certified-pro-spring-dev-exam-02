package com.apress.cems.beans.ci;

/**
 * @author Iuliana Cosmina
 * @since 1.0
 */
public interface Item {
    String getTitle();
}
