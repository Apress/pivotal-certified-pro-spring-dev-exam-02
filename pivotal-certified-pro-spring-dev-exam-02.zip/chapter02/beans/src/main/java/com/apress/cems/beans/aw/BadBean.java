package com.apress.cems.beans.aw;

/**
 * @author Iuliana Cosmina
 * @since 1.0
 */
public interface BadBean {
    MissingBean getMissingBean();

    BeanTwo getBeanTwo();
}
