package com.apress.cems.beans.misc;

/**
 * @author Iuliana Cosmina
 * @since 1.0
 */
public interface TaxFormula {
     String getFormula();
}
