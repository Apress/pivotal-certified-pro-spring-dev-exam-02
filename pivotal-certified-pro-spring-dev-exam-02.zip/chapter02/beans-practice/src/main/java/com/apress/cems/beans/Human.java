package com.apress.cems.beans;

/**
 * @author Iuliana Cosmina
 * @since 1.0
 */
public interface Human {

    Item getItem();
}
