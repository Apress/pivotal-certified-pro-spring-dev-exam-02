/**
 * @author Iuliana Cosmina
 * @since 1.0
 */module com.apress.cems.beans.practice {
    requires com.apress.cems.dao;
    requires java.sql;
    requires org.slf4j;
    requires spring.context;
    requires spring.beans;
}