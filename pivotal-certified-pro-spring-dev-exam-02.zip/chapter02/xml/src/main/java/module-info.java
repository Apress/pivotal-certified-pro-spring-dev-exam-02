/**
 * @author Iuliana Cosmina
 * @since 1.0
 */
module com.apress.cems.xml {
    requires com.apress.cems.dao;
    requires com.apress.cems.pojos;
    requires org.apache.commons.lang3;
    requires java.sql;
    requires org.slf4j;
}