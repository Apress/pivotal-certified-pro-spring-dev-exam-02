package com.apress.cems.util;

/**
 * @author Iuliana Cosmina
 * @since 1.0
 */
public enum CaseType {
    UNCATEGORIZED,
    INFRACTION,
    MISDEMEANOR,
    FELONY
}