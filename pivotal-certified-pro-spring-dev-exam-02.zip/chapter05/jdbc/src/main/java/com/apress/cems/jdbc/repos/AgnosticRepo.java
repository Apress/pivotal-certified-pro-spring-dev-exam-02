package com.apress.cems.jdbc.repos;

/**
 * @author Iuliana Cosmina
 * @since 1.0
 */
public interface AgnosticRepo {
    int createTable(String name);
}
