/**
 * @author Iuliana Cosmina
 * @since 1.0
 * Description: this package contains sources to test a Spring configuration with multiple transaction managers, when one of them is set as @Primary.
 */
package com.apress.cems.tx.three;