/**
 * @author Iuliana Cosmina
 * @since 1.0
 * Description: this package contains sources to test a Spring configuration with multiple transaction managers, when none of them is set as default.
 */
package com.apress.cems.tx.two;